#reset
scoreboard objectives remove temp
scoreboard objectives add temp dummy

execute store result score $pos temp run data get entity @s Pos[1] 100
execute store result score $posfloor temp run data get entity @s Pos[1]
kill @s

scoreboard players set #const100 temp 100
scoreboard players operation $posfloor temp *= #const100 temp

scoreboard players operation $pos temp -= $posfloor temp

execute if score $pos temp matches 50.. run return 2
execute if score $pos temp matches ..50 run return 1